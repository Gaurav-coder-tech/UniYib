package com.example.uniyib

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.uniyib.adapters.PostAdapter
import com.example.uniyib.adapters.StoryAdapter
import com.example.uniyib.models.Post
import com.example.uniyib.models.Story
import com.google.android.material.bottomnavigation.BottomNavigationView

class HomeActivity : AppCompatActivity() {

    private lateinit var storyRecyclerView: RecyclerView
    private lateinit var postRecyclerView: RecyclerView
    private lateinit var bottomNavigationView: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Initialize RecyclerViews
        storyRecyclerView = findViewById(R.id.rvStories)
        postRecyclerView = findViewById(R.id.rvPosts)

        // Set layout managers
        storyRecyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        postRecyclerView.layoutManager = LinearLayoutManager(this)

        // Setup mock data for stories
        val storyList = listOf(
            Story("Your Story", R.drawable.uniyib_logo),
            Story("Utkarsh Raj", R.drawable.ic_user),
            Story("Niraj Kumar", R.drawable.ic_user),
            Story("Gaurav Kumar", R.drawable.ic_user),
            Story("Mobashir Imam", R.drawable.ic_user),
        )
        storyRecyclerView.adapter = StoryAdapter(storyList)

        // Setup mock data for posts
        val postList = listOf(
            Post("Utkarsh Raj", "Education changes lives!", R.drawable.post_image_placeholder1),
            Post("Niraj Kumar", "Check out this cool innovation!", R.drawable.post_image_placeholder2),
            Post("Gaurav Kumar", "Work hard, build a brand 💼", R.drawable.post_image_placeholder3),
            Post("Mobashir Imam", "Work hard, build a brand 💼", R.drawable.post_image_placeholder4)
        )
        postRecyclerView.adapter = PostAdapter(postList)

        // Bottom Navigation
        bottomNavigationView = findViewById(R.id.bottom_navigation)
        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    // Already on Home
                    true
                }
                R.id.nav_search -> {
                    Toast.makeText(this, "Search Clicked", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.nav_post -> {
                    Toast.makeText(this, "Create Post Clicked", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.nav_notifications -> {
                    Toast.makeText(this, "Notifications Clicked", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.nav_profile -> {
                    Toast.makeText(this, "Profile Clicked", Toast.LENGTH_SHORT).show()
                    true
                }
                else -> false
            }
        }
    }
}
