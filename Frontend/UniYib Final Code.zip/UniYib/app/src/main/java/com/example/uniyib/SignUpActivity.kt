package com.example.uniyib

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class SignUpActivity : AppCompatActivity() {

    private lateinit var dobEditText: EditText
    private lateinit var loginRedirect: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        // Handle Date Picker
        dobEditText = findViewById(R.id.et_dob)
        dobEditText.setOnClickListener {
            showDatePicker()
        }

        // Redirect to login page
        loginRedirect = findViewById(R.id.login_redirect)
        loginRedirect.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        // You can add logic for image click and form validation here if needed
    }

    @SuppressLint("SetTextI18n")
    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePicker = DatePickerDialog(this, { _, y, m, d ->
            dobEditText.setText("$d/${m + 1}/$y")
        }, year, month, day)

        datePicker.show()
    }
}
