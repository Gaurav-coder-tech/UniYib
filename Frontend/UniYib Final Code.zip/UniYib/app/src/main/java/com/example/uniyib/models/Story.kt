package com.example.uniyib.models

data class Story(val username: String, val imageResId: Int)
