package com.example.uniyib.models

data class Post(val username: String, val description: String, val imageResId: Int)
