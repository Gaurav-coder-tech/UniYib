package com.example.uniyib

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView

class HomeActivity : AppCompatActivity() {

    private lateinit var bottomNavigationView: BottomNavigationView
    private lateinit var postsRecyclerView: RecyclerView
    private lateinit var postsAdapter: PostsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        bottomNavigationView = findViewById(R.id.bottom_navigation)
        postsRecyclerView = findViewById(R.id.postsRecyclerView)

        postsRecyclerView.layoutManager = LinearLayoutManager(this)
        postsAdapter = PostsAdapter(getPosts()) // Get posts and set them in the adapter
        postsRecyclerView.adapter = postsAdapter

        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_profile -> {
                    // Navigate to profile activity
                    startActivity(Intent(this, ProfileActivity::class.java))
                    true
                }
                R.id.nav_chat -> {
                    // Handle chat navigation
                    Toast.makeText(this, "Chat", Toast.LENGTH_SHORT).show()
                    true
                }
                else -> false
            }
        }
    }

    private fun getPosts(): List<Post> {
        // Return a list of posts
        return listOf(
            Post("Education Post", "Some content about education."),
            Post("Entertainment Post", "Some content about entertainment."),
            Post("Innovation Post", "Some content about innovation."),
            Post("Business Post", "Some content about business.")
        )
    }
}
