data class Post(val title: String, val content: String)
